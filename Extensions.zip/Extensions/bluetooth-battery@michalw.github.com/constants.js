export const UUID = "bluetooth-battery@michalw.github.com";
export const PYTHON_SCRIPT_PATH = 'Bluetooth_Headset_Battery_Level/bluetooth_battery.py';
export const BTCTL_SCRIPT_PATH = 'scripts/bluetoothctl_battery.sh'
export const UPOWER_SCRIPT_PATH = 'scripts/upower_battery.sh'
export const TOGGLE_SCRIPT_PATH = 'scripts/bluetoothctl_toggle.sh';
